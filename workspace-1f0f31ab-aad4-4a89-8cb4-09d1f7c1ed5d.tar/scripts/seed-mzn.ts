import { PrismaClient } from '@prisma/client';
import crypto from 'crypto';

const db = new PrismaClient();

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

const PRODUCTS = [
  // FEMININO
  { slug: 'doce-onda', name: 'Doce Onda', inspiration: 'Good Girl — Carolina Herrera', gender: 'FEMININO', notes: 'Amêndoa, cacau, baunilha e tuberosa', description: 'Um doce sofisticado e marcante, perfeito para noites especiais. Fixação intensa que acompanha você por horas.', price: 119.9, sortOrder: 1 },
  { slug: 'realeza', name: 'Realeza', inspiration: 'La Vie Est Belle — Lancôme', gender: 'FEMININO', notes: 'Íris, pralinê, groselha e patchouli', description: 'Doce elegante com toque gourmet de pralinê. Uma fragrância alegre e envolvente para o dia a dia.', price: 109.9, sortOrder: 2 },
  { slug: 'parisienne', name: 'Parisienne', inspiration: 'Coco Mademoiselle — Chanel', gender: 'FEMININO', notes: 'Rosa, jasmim, patchouli e vetiver', description: 'Chique e independente, com um fundo amadeirado inconfundível. Elegância parisiense em cada borrifada.', price: 129.9, sortOrder: 3 },
  { slug: 'peonia-negra', name: 'Peônia Negra', inspiration: 'Flowerbomb — Viktor & Rolf', gender: 'FEMININO', notes: 'Peônia, jasmim, orquídea e patchouli', description: 'Explosão floral intensa com fundo adocicado. Uma verdadeira bomba de flores que chama atenção.', price: 115.9, sortOrder: 4 },
  // MASCULINO
  { slug: 'icone-azul', name: 'Ícone Azul', inspiration: 'Bleu de Chanel — Chanel', gender: 'MASCULINO', notes: 'Toranja, incenso, cedro e gengibre', description: 'Amadeirado aromático de elegância absoluta. O clássico do homem sofisticado e confiante.', price: 129.9, sortOrder: 5 },
  { slug: 'um-milhao', name: 'Um Milhão', inspiration: 'One Million — Paco Rabanne', gender: 'MASCULINO', notes: 'Couro, canela, rosa e âmbar', description: 'Audacioso e vibrante, com calor de couro e especiarias. Para quem quer deixar marca por onde passa.', price: 109.9, sortOrder: 6 },
  { slug: 'cafe-imperial', name: 'Café Imperial', inspiration: 'Malbec — O Boticário', gender: 'MASCULINO', notes: 'Café, bergamota, madeiras e couro', description: 'A energia do café brasileiro em uma fragrância amadeirada e marcante. Nacional queridinho.', price: 89.9, sortOrder: 7 },
  { slug: 'selva-dourada', name: 'Selva Dourada', inspiration: 'Sauvage — Dior', gender: 'MASCULINO', notes: 'Bergamota, pimenta sichuan, âmbar e lavanda', description: 'Fresco e selvagem ao mesmo tempo, com brilho dourado de âmbar. Presença e força natural.', price: 125.9, sortOrder: 8 },
  // UNISSEX
  { slug: 'cristal-ouro', name: 'Cristal de Ouro', inspiration: 'Baccarat Rouge 540 — M. F. Kurkdjian', gender: 'UNISSEX', notes: 'Açafrão, jasmim, âmbar e madeiras', description: 'O cultuado perfume joia, com seu accorde cristalino agridoce inconfundível. Puro luxo.', price: 129.9, sortOrder: 9 },
  { slug: 'neroli-riviera', name: 'Neroli Riviera', inspiration: 'Neroli Portofino — Tom Ford', gender: 'UNISSEX', notes: 'Neroli, bergamota, limão e flor de laranjeira', description: 'Verão na Riviera italiana: cítrico, fresco e sofisticado. Uma viagem a cada borrifada.', price: 129.9, sortOrder: 10 },
  { slug: 'fumaca-mel', name: 'Fumaça & Mel', inspiration: 'Tobacco Vanille — Tom Ford', gender: 'UNISSEX', notes: 'Tabaco, baunilha, cacau e especiarias', description: 'Quente e envolvente como uma destilaria inglesa. Doce de tabaco com baunilha cremosa.', price: 125.9, sortOrder: 11 },
  { slug: 'santal-imperial', name: 'Santal Imperial', inspiration: 'Santal 33 — Le Labo', gender: 'UNISSEX', notes: 'Sândalo, couro, íris e cardamomo', description: 'O sândalo icônico de Nova York. Minimalista, sedoso e absolutamente viciante.', price: 129.9, sortOrder: 12 },
];

async function main() {
  // Admin
  const adminCount = await db.adminUser.count();
  if (adminCount === 0) {
    await db.adminUser.create({
      data: { username: 'admin', passwordHash: hashPassword('mzn2026') },
    });
    console.log('Admin criado: admin / mzn2026');
  } else {
    console.log('Admin já existe, mantido.');
  }

  // Settings
  await db.storeSettings.upsert({
    where: { id: 'main' },
    update: {},
    create: { id: 'main', whatsapp: '5511999999999', instagram: '@mzninspiracoes' },
  });
  console.log('Configurações garantidas.');

  // Produtos
  for (const p of PRODUCTS) {
    const data = {
      name: p.name,
      inspiration: p.inspiration,
      gender: p.gender,
      notes: p.notes,
      description: p.description,
      price: p.price,
      volume: '50ml',
      imageUrl: `/images/perfumes/${p.slug}.png`,
      active: true,
      sortOrder: p.sortOrder,
    };
    const existing = await db.product.findFirst({ where: { name: p.name } });
    if (existing) {
      await db.product.update({ where: { id: existing.id }, data });
      console.log(`Atualizado: ${p.name}`);
    } else {
      await db.product.create({ data });
      console.log(`Criado: ${p.name}`);
    }
  }
  console.log('Seed concluído.');
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

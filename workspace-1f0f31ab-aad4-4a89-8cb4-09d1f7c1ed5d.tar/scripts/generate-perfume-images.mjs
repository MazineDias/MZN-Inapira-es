import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import path from 'path';

const OUT_DIR = '/home/z/my-project/public/images/perfumes';
const HERO_PATH = '/home/z/my-project/public/images/hero.png';

const BASE_STYLE =
  'Professional luxury product photography, single elegant artisanal perfume bottle centered on white marble surface, ivory white background with soft golden light accents and subtle gold bokeh, studio lighting, soft reflections, high-end cosmetics advertisement style, photorealistic, high quality, detailed, no text, no label, no words, no watermark';

const PRODUCTS = [
  { slug: 'doce-onda',      desc: 'sleek rectangular glass bottle with warm amber-honey colored liquid and ornate polished gold round cap' },
  { slug: 'realeza',        desc: 'round faceted crystal bottle with blush pink rose liquid, delicate gold ribbon detail around the neck, golden sphere cap' },
  { slug: 'parisienne',     desc: 'classic rectangular clear glass bottle with light champagne liquid and minimalist flat gold cap' },
  { slug: 'peonia-negra',   desc: 'faceted diamond-shaped crystal bottle with deep rose magenta liquid and golden accent details' },
  { slug: 'icone-azul',     desc: 'rectangular heavy glass bottle with deep navy blue gradient liquid and shiny gold cylindrical cap' },
  { slug: 'um-milhao',      desc: 'golden ingot-shaped faceted bottle with metallic radiant gold liquid' },
  { slug: 'cafe-imperial',  desc: 'dark espresso brown opaque glass bottle with coffee-toned liquid hints and brushed gold cap' },
  { slug: 'selva-dourada',  desc: 'tall musculine bottle with dark smoky glass and gradient amber liquid, gold-topped cap' },
  { slug: 'cristal-ouro',   desc: 'precious faceted clear crystal bottle with glowing amber-gold luminous liquid, jewel-like edges' },
  { slug: 'neroli-riviera', desc: 'clear elegant glass bottle with pale citrine yellow liquid and slim gold-tone cap, fresh citrus mood' },
  { slug: 'fumaca-mel',     desc: 'apothecary-style dark amber glass bottle with rich brown liquid and antique gold cap, warm honey glow' },
  { slug: 'santal-imperial',desc: 'tall cylindrical smoky glass bottle with pale sand beige liquid and brushed gold wooden cap' },
];

function withTimeout(promise, ms) {
  return Promise.race([
    promise,
    new Promise((_, reject) =>
      setTimeout(() => reject(new Error(`Timeout de ${ms / 1000}s na geracao`)), ms)
    ),
  ]);
}

async function generateOne(zai, prompt, outputPath, retries = 2) {
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const response = await withTimeout(
        zai.images.generations.create({
          prompt,
          size: outputPath === HERO_PATH ? '1344x768' : '1024x1024',
        }),
        150000
      );
      const imageBase64 = response?.data?.[0]?.base64;
      if (!imageBase64) throw new Error('Resposta invalida da API de imagem');
      const buffer = Buffer.from(imageBase64, 'base64');
      if (buffer.length < 10000) throw new Error('Imagem muito pequena/corrompida');
      fs.writeFileSync(outputPath, buffer);
      console.log(`OK: ${path.basename(outputPath)} (${Math.round(buffer.length / 1024)} KB)`);
      return true;
    } catch (err) {
      console.error(`Erro tentativa ${attempt} para ${path.basename(outputPath)}: ${err.message}`);
      if (attempt < retries) await new Promise((r) => setTimeout(r, 1500 * attempt));
    }
  }
  return false;
}

async function main() {
  fs.mkdirSync(OUT_DIR, { recursive: true });
  fs.mkdirSync(path.dirname(HERO_PATH), { recursive: true });
  const zai = await ZAI.create();

  const results = { ok: 0, fail: 0, failedSlugs: [] };

  console.log('Gerando imagem hero...');
  if (await generateOne(zai, `${BASE_STYLE}, luxury perfume collection of five artisanal glass bottles in white cream and gold tones arranged on marble podiums, flowing golden silk fabric behind`, HERO_PATH)) results.ok++; else { results.fail++; results.failedSlugs.push('hero'); }

  for (const p of PRODUCTS) {
    const out = path.join(OUT_DIR, `${p.slug}.png`);
    if (fs.existsSync(out) && fs.statSync(out).size > 10000) {
      console.log(`SKIP (ja existe): ${p.slug}.png`);
      results.ok++;
      continue;
    }
    console.log(`Gerando: ${p.slug}...`);
    if (await generateOne(zai, `${BASE_STYLE}, ${p.desc}`, out)) results.ok++; else { results.fail++; results.failedSlugs.push(p.slug); }
  }

  console.log(`\nRESUMO: ${results.ok} ok, ${results.fail} falhas`);
  if (results.failedSlugs.length) console.log('FALHARAM: ' + results.failedSlugs.join(', '));
  console.log('DONE');
}

main().catch((e) => { console.error('FATAL:', e); process.exit(1); });

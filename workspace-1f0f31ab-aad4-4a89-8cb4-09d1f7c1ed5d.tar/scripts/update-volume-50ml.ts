import { PrismaClient } from '@prisma/client';

const db = new PrismaClient();

async function main() {
  const result = await db.product.updateMany({
    where: { volume: '30ml' },
    data: { volume: '50ml' },
  });
  console.log(`Produtos atualizados de 30ml para 50ml: ${result.count}`);

  const volumes = await db.product.groupBy({
    by: ['volume'],
    _count: { volume: true },
  });
  console.log('Volumes no banco:', JSON.stringify(volumes));
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());

import { MznApp } from "@/components/mzn/mzn-app";

export default function Home() {
  return <MznApp />;
}

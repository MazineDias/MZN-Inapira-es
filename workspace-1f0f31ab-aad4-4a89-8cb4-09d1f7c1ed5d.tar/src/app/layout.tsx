import type { Metadata, Viewport } from "next";
import { Cormorant_Garamond, Jost } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const displayFont = Cormorant_Garamond({
  variable: "--font-display-src",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
});

const bodyFont = Jost({
  variable: "--font-body-src",
  subsets: ["latin"],
  weight: ["300", "400", "500", "600"],
});

export const metadata: Metadata = {
  title: "MZN Inspirações — Perfumes Artesanais Inspirados nas Grandes Grifes",
  description:
    "Perfumes artesanais inspirados nas grandes marcas e grifes. Óleos concentrados, fixação prolongada e frascos elegantes de 50ml. MZN Inspirações — luxo acessível.",
  keywords: [
    "perfumes artesanais",
    "perfumes inspirados",
    "MZN Inspirações",
    "perfumaria artesanal",
    "fragrâncias de grife",
  ],
  icons: {
    icon: "/logo-mzn.svg",
  },
  openGraph: {
    title: "MZN Inspirações",
    description: "Perfumes artesanais inspirados nas grandes grifes.",
    type: "website",
  },
};

export const viewport: Viewport = {
  themeColor: "#A8842C",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <body
        className={`${displayFont.variable} ${bodyFont.variable} font-sans antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}

import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Catálogo público: somente produtos ativos
export async function GET() {
  try {
    const products = await db.product.findMany({
      where: { active: true },
      orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
    });
    return NextResponse.json({ products });
  } catch {
    return NextResponse.json(
      { error: 'Erro ao carregar produtos.' },
      { status: 500 }
    );
  }
}

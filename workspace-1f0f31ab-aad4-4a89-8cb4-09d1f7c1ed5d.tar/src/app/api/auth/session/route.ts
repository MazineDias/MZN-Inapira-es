import { NextRequest, NextResponse } from 'next/server';
import { getAdminFromRequest } from '@/lib/auth';

export async function GET(req: NextRequest) {
  const admin = await getAdminFromRequest(req);
  return NextResponse.json({
    authenticated: !!admin,
    username: admin?.username ?? null,
  });
}

import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import {
  createSessionToken,
  setSessionCookie,
  verifyPassword,
} from '@/lib/auth';

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as { username?: string; password?: string };
    const username = body.username?.trim();
    const password = body.password ?? '';

    if (!username || !password) {
      return NextResponse.json(
        { error: 'Informe usuário e senha.' },
        { status: 400 }
      );
    }

    const admin = await db.adminUser.findUnique({ where: { username } });
    if (!admin || !verifyPassword(password, admin.passwordHash)) {
      return NextResponse.json(
        { error: 'Usuário ou senha incorretos.' },
        { status: 401 }
      );
    }

    const res = NextResponse.json({
      ok: true,
      admin: { id: admin.id, username: admin.username },
    });
    setSessionCookie(res, createSessionToken(admin.id));
    return res;
  } catch {
    return NextResponse.json({ error: 'Erro ao fazer login.' }, { status: 500 });
  }
}

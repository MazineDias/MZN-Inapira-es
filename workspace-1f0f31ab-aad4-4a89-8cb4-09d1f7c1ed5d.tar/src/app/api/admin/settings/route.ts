import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { getAdminFromRequest, requireAdmin } from '@/lib/auth';

// GET público: a vitrine precisa do WhatsApp/Instagram para o botão de contato
export async function GET() {
  const settings = await db.storeSettings.findUnique({ where: { id: 'main' } });
  return NextResponse.json({
    whatsapp: settings?.whatsapp ?? '5511999999999',
    instagram: settings?.instagram ?? '@mzninspiracoes',
  });
}

const settingsSchema = z.object({
  whatsapp: z
    .string()
    .trim()
    .regex(/^\d{10,15}$/, 'WhatsApp deve conter apenas números com DDI+DDD (ex.: 5511999999999)'),
  instagram: z.string().trim().max(60).default(''),
});

export async function PUT(req: NextRequest) {
  const admin = await getAdminFromRequest(req);
  const denied = requireAdmin(admin);
  if (denied) return denied;

  try {
    const parsed = settingsSchema.safeParse(await req.json());
    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.issues[0]?.message ?? 'Dados inválidos.' },
        { status: 400 }
      );
    }
    await db.storeSettings.upsert({
      where: { id: 'main' },
      update: parsed.data,
      create: { id: 'main', ...parsed.data },
    });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json(
      { error: 'Erro ao salvar configurações.' },
      { status: 500 }
    );
  }
}

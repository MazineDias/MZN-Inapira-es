import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import {
  getAdminFromRequest,
  hashPassword,
  requireAdmin,
  verifyPassword,
} from '@/lib/auth';

const passwordSchema = z.object({
  currentPassword: z.string().min(1, 'Informe a senha atual'),
  newPassword: z.string().min(6, 'A nova senha deve ter no mínimo 6 caracteres'),
});

export async function PUT(req: NextRequest) {
  const admin = await getAdminFromRequest(req);
  const denied = requireAdmin(admin);
  if (denied) return denied;

  try {
    const parsed = passwordSchema.safeParse(await req.json());
    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.issues[0]?.message ?? 'Dados inválidos.' },
        { status: 400 }
      );
    }

    const record = await db.adminUser.findUnique({ where: { id: admin!.id } });
    if (!record || !verifyPassword(parsed.data.currentPassword, record.passwordHash)) {
      return NextResponse.json(
        { error: 'Senha atual incorreta.' },
        { status: 400 }
      );
    }

    await db.adminUser.update({
      where: { id: record.id },
      data: { passwordHash: hashPassword(parsed.data.newPassword) },
    });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json(
      { error: 'Erro ao alterar senha.' },
      { status: 500 }
    );
  }
}

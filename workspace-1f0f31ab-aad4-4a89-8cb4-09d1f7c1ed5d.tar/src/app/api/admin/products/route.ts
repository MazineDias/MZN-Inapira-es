import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { getAdminFromRequest, requireAdmin } from '@/lib/auth';

const productSchema = z.object({
  name: z.string().trim().min(2, 'Nome muito curto').max(80),
  inspiration: z.string().trim().min(2, 'Informe a inspiração').max(120),
  gender: z.enum(['FEMININO', 'MASCULINO', 'UNISSEX']),
  notes: z.string().trim().max(160).default(''),
  description: z.string().trim().max(500).default(''),
  price: z.number().nonnegative('Preço inválido').max(100000),
  volume: z.string().trim().max(20).default('50ml'),
  imageUrl: z.string().trim().max(300).default(''),
  active: z.boolean().default(true),
  sortOrder: z.number().int().default(99),
});

export async function GET(req: NextRequest) {
  const admin = await getAdminFromRequest(req);
  const denied = requireAdmin(admin);
  if (denied) return denied;

  const products = await db.product.findMany({
    orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
  });
  return NextResponse.json({ products });
}

export async function POST(req: NextRequest) {
  const admin = await getAdminFromRequest(req);
  const denied = requireAdmin(admin);
  if (denied) return denied;

  try {
    const json = await req.json();
    const parsed = productSchema.safeParse(json);
    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.issues[0]?.message ?? 'Dados inválidos.' },
        { status: 400 }
      );
    }
    const data = parsed.data;
    const imageUrl =
      data.imageUrl ||
      '/images/perfumes/cristal-ouro.png'; // imagem padrão elegante

    const product = await db.product.create({
      data: { ...data, imageUrl },
    });
    return NextResponse.json({ product }, { status: 201 });
  } catch {
    return NextResponse.json(
      { error: 'Erro ao criar produto.' },
      { status: 500 }
    );
  }
}

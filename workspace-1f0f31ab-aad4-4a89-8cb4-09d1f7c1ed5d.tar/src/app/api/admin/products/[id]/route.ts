import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { getAdminFromRequest, requireAdmin } from '@/lib/auth';

const updateSchema = z.object({
  name: z.string().trim().min(2).max(80).optional(),
  inspiration: z.string().trim().min(2).max(120).optional(),
  gender: z.enum(['FEMININO', 'MASCULINO', 'UNISSEX']).optional(),
  notes: z.string().trim().max(160).optional(),
  description: z.string().trim().max(500).optional(),
  price: z.number().nonnegative().max(100000).optional(),
  volume: z.string().trim().max(20).optional(),
  imageUrl: z.string().trim().max(300).optional(),
  active: z.boolean().optional(),
  sortOrder: z.number().int().optional(),
});

type RouteContext = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, ctx: RouteContext) {
  const admin = await getAdminFromRequest(req);
  const denied = requireAdmin(admin);
  if (denied) return denied;

  const { id } = await ctx.params;

  try {
    const json = await req.json();
    const parsed = updateSchema.safeParse(json);
    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.issues[0]?.message ?? 'Dados inválidos.' },
        { status: 400 }
      );
    }
    const existing = await db.product.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json(
        { error: 'Produto não encontrado.' },
        { status: 404 }
      );
    }
    const product = await db.product.update({ where: { id }, data: parsed.data });
    return NextResponse.json({ product });
  } catch {
    return NextResponse.json(
      { error: 'Erro ao atualizar produto.' },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest, ctx: RouteContext) {
  const admin = await getAdminFromRequest(req);
  const denied = requireAdmin(admin);
  if (denied) return denied;

  const { id } = await ctx.params;
  try {
    const existing = await db.product.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json(
        { error: 'Produto não encontrado.' },
        { status: 404 }
      );
    }
    await db.product.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json(
      { error: 'Erro ao excluir produto.' },
      { status: 500 }
    );
  }
}

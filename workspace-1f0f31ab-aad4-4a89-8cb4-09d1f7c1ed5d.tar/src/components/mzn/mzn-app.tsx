"use client";

import { useCallback, useEffect, useState } from "react";
import { Storefront } from "@/components/mzn/storefront";
import { AdminPanel } from "@/components/mzn/admin";
import {
  type AdminSessionInfo,
  type MznSettings,
} from "@/components/mzn/types";

function readViewFromHash(): "store" | "admin" {
  if (typeof window === "undefined") return "store";
  return window.location.hash === "#admin" ? "admin" : "store";
}

export function MznApp() {
  const [view, setView] = useState<"store" | "admin">("store");
  const [session, setSession] = useState<AdminSessionInfo | null>(null);
  const [sessionLoading, setSessionLoading] = useState(true);
  const [settings, setSettings] = useState<MznSettings | null>(null);

  const refreshSession = useCallback(async () => {
    setSessionLoading(true);
    try {
      const res = await fetch("/api/auth/session");
      const data = (await res.json()) as AdminSessionInfo;
      setSession(data);
    } catch {
      setSession({ authenticated: false, username: null });
    } finally {
      setSessionLoading(false);
    }
  }, []);

  const loadSettings = useCallback(async () => {
    try {
      const res = await fetch("/api/admin/settings");
      const data = (await res.json()) as MznSettings;
      setSettings(data);
    } catch {
      setSettings({ whatsapp: "5511999999999", instagram: "@mzninspiracoes" });
    }
  }, []);

  useEffect(() => {
    setView(readViewFromHash());
    const onHashChange = () => {
      setView(readViewFromHash());
      window.scrollTo({ top: 0 });
    };
    window.addEventListener("hashchange", onHashChange);
    return () => window.removeEventListener("hashchange", onHashChange);
  }, []);

  useEffect(() => {
    refreshSession();
    loadSettings();
  }, [refreshSession, loadSettings]);

  const goAdmin = useCallback(() => {
    window.location.hash = "#admin";
    window.scrollTo({ top: 0 });
  }, []);

  const exitToStore = useCallback(() => {
    if (window.location.hash === "#admin") {
      window.location.hash = "#";
    }
    setView("store");
    window.scrollTo({ top: 0 });
  }, []);

  if (view === "admin") {
    return (
      <AdminPanel
        session={session}
        sessionLoading={sessionLoading}
        settings={settings}
        onSessionRefresh={refreshSession}
        onExitStore={exitToStore}
      />
    );
  }

  return <Storefront settings={settings ?? { whatsapp: "5511999999999", instagram: "@mzninspiracoes" }} onOpenAdmin={goAdmin} />;
}

export type Gender = "FEMININO" | "MASCULINO" | "UNISSEX";

export type MznProduct = {
  id: string;
  name: string;
  inspiration: string;
  gender: string;
  notes: string;
  description: string;
  price: number;
  volume: string;
  imageUrl: string;
  active: boolean;
  sortOrder: number;
};

export type MznSettings = {
  whatsapp: string;
  instagram: string;
};

export type AdminSessionInfo = {
  authenticated: boolean;
  username: string | null;
};

export const brl = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
});

export function formatPrice(value: number): string {
  return brl.format(value);
}

export function whatsappLink(number: string, message: string): string {
  return `https://wa.me/${number.replace(/\D/g, "")}?text=${encodeURIComponent(message)}`;
}

export const GENDER_LABEL: Record<string, string> = {
  FEMININO: "Feminino",
  MASCULINO: "Masculino",
  UNISSEX: "Unissex",
};

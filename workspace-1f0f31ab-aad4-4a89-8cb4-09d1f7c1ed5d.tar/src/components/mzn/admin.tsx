"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Image from "next/image";
import {
  Check,
  ImageOff,
  KeyRound,
  LogOut,
  Pencil,
  Plus,
  Save,
  Search,
  Store,
  Tag,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import {
  formatPrice,
  GENDER_LABEL,
  type AdminSessionInfo,
  type MznProduct,
  type MznSettings,
} from "@/components/mzn/types";

/* ---------------------------- LOGIN ---------------------------- */

function LoginForm({
  onSuccess,
  onBackToStore,
}: {
  onSuccess: () => void;
  onBackToStore: () => void;
}) {
  const { toast } = useToast();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "Não foi possível entrar.");
        return;
      }
      toast({
        title: "Bem-vindo(a)!",
        description: "Login realizado com sucesso.",
      });
      onSuccess();
    } catch {
      setError("Erro de conexão. Tente novamente.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-cream px-4 py-10">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <Image
            src="/logo-mzn.svg"
            alt="Logotipo MZN Inspirações"
            width={88}
            height={88}
            className="mx-auto h-16 w-16"
            priority
          />
          <h1 className="mt-4 font-display text-3xl font-semibold text-gold-deep">
            Painel <span className="gold-gradient-text">Administrativo</span>
          </h1>
          <p className="mt-1 text-sm text-ink/60">
            Acesso restrito à equipe MZN Inspirações
          </p>
        </div>
        <form
          onSubmit={handleSubmit}
          className="space-y-5 rounded-2xl border border-[#eadfca] bg-white p-8 shadow-[0_16px_50px_-24px_rgba(124,98,26,0.4)]"
        >
          <div className="space-y-2">
            <Label htmlFor="username">Usuário</Label>
            <Input
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="admin"
              autoComplete="username"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Senha</Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              autoComplete="current-password"
              required
            />
          </div>
          {error && (
            <p className="rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive" role="alert">
              {error}
            </p>
          )}
          <Button type="submit" className="h-11 w-full rounded-full text-base" disabled={loading}>
            {loading ? "Entrando..." : "Entrar"}
          </Button>
          <button
            type="button"
            onClick={onBackToStore}
            className="block w-full text-center text-sm text-ink/60 transition-colors hover:text-gold"
          >
            ← Voltar à loja
          </button>
        </form>
      </div>
    </div>
  );
}

/* ---------------------- FORMULÁRIO DE PRODUTO ---------------------- */

type ProductForm = {
  name: string;
  inspiration: string;
  gender: string;
  notes: string;
  description: string;
  price: string;
  volume: string;
  imageUrl: string;
  active: boolean;
};

const EMPTY_FORM: ProductForm = {
  name: "",
  inspiration: "",
  gender: "UNISSEX",
  notes: "",
  description: "",
  price: "",
  volume: "50ml",
  imageUrl: "",
  active: true,
};

function ProductDialog({
  open,
  product,
  onClose,
  onSaved,
}: {
  open: boolean;
  product: MznProduct | null;
  onClose: () => void;
  onSaved: (p: MznProduct, isNew: boolean) => void;
}) {
  const { toast } = useToast();
  const [form, setForm] = useState<ProductForm>(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setError(null);
      setForm(
        product
          ? {
              name: product.name,
              inspiration: product.inspiration,
              gender: product.gender,
              notes: product.notes,
              description: product.description,
              price: String(product.price),
              volume: product.volume,
              imageUrl: product.imageUrl,
              active: product.active,
            }
          : EMPTY_FORM
      );
    }
  }, [open, product]);

  function set<K extends keyof ProductForm>(key: K, value: ProductForm[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSave() {
    const price = Number(form.price.replace(",", "."));
    if (!form.name.trim() || !form.inspiration.trim()) {
      setError("Informe nome e inspiração do perfume.");
      return;
    }
    if (!Number.isFinite(price) || price <= 0) {
      setError("Informe um preço válido (ex.: 119.90).");
      return;
    }
    setSaving(true);
    setError(null);
    const payload = {
      name: form.name.trim(),
      inspiration: form.inspiration.trim(),
      gender: form.gender,
      notes: form.notes.trim(),
      description: form.description.trim(),
      price,
      volume: form.volume.trim() || "50ml",
      imageUrl: form.imageUrl.trim(),
      active: form.active,
      sortOrder: product?.sortOrder ?? 99,
    };
    try {
      const res = await fetch(
        product ? `/api/admin/products/${product.id}` : "/api/admin/products",
        {
          method: product ? "PATCH" : "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        }
      );
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "Erro ao salvar produto.");
        return;
      }
      toast({
        title: product ? "Produto atualizado!" : "Produto criado!",
        description: `${payload.name} — ${formatPrice(price)}`,
      });
      onSaved(data.product as MznProduct, !product);
      onClose();
    } catch {
      setError("Erro de conexão. Tente novamente.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg gold-scrollbar">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl text-gold-deep">
            {product ? "Editar produto" : "Novo produto"}
          </DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-2">
          <div className="grid gap-2">
            <Label htmlFor="pf-name">Nome *</Label>
            <Input id="pf-name" value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="Ex.: Doce Onda" />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="pf-insp">Inspirado em *</Label>
            <Input id="pf-insp" value={form.inspiration} onChange={(e) => set("inspiration", e.target.value)} placeholder="Ex.: Good Girl — Carolina Herrera" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label>Gênero</Label>
              <Select value={form.gender} onValueChange={(v) => set("gender", v)}>
                <SelectTrigger aria-label="Gênero do perfume">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="FEMININO">Feminino</SelectItem>
                  <SelectItem value="MASCULINO">Masculino</SelectItem>
                  <SelectItem value="UNISSEX">Unissex</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="pf-price">Preço (R$) *</Label>
              <Input
                id="pf-price"
                inputMode="decimal"
                value={form.price}
                onChange={(e) => set("price", e.target.value)}
                placeholder="119.90"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="pf-volume">Volume</Label>
              <Input id="pf-volume" value={form.volume} onChange={(e) => set("volume", e.target.value)} placeholder="50ml" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="pf-img">Imagem (URL)</Label>
              <Input id="pf-img" value={form.imageUrl} onChange={(e) => set("imageUrl", e.target.value)} placeholder="/images/perfumes/doce-onda.png" />
            </div>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="pf-notes">Notas olfativas</Label>
            <Input id="pf-notes" value={form.notes} onChange={(e) => set("notes", e.target.value)} placeholder="Ex.: Amêndoa, cacau e baunilha" />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="pf-desc">Descrição</Label>
            <Input id="pf-desc" value={form.description} onChange={(e) => set("description", e.target.value)} placeholder="Frase curta que aparece no site" />
          </div>
          <div className="flex items-center justify-between rounded-xl border border-[#eadfca] px-4 py-3">
            <Label htmlFor="pf-active" className="cursor-pointer">
              Visível na loja
            </Label>
            <Switch id="pf-active" checked={form.active} onCheckedChange={(v) => set("active", v)} />
          </div>
          {error && (
            <p className="rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive" role="alert">
              {error}
            </p>
          )}
        </div>
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose} disabled={saving}>
            Cancelar
          </Button>
          <Button onClick={handleSave} disabled={saving} className="min-w-32">
            {saving ? "Salvando..." : product ? "Salvar alterações" : "Criar produto"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* --------------------------- LINHA DE PRODUTO --------------------------- */

function ProductRow({
  product,
  onUpdated,
  onEdit,
  onDelete,
}: {
  product: MznProduct;
  onUpdated: (p: MznProduct) => void;
  onEdit: (p: MznProduct) => void;
  onDelete: (p: MznProduct) => void;
}) {
  const { toast } = useToast();
  const [draft, setDraft] = useState<string>(String(product.price));
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setDraft(String(product.price));
  }, [product.price]);

  const parsed = Number(draft.replace(",", "."));
  const changed = Number.isFinite(parsed) && parsed !== product.price;

  async function savePrice() {
    if (!Number.isFinite(parsed) || parsed <= 0) {
      toast({
        title: "Preço inválido",
        description: "Informe um valor maior que zero (ex.: 119.90).",
        variant: "destructive",
      });
      return;
    }
    setSaving(true);
    try {
      const res = await fetch(`/api/admin/products/${product.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ price: parsed }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast({
          title: "Erro ao atualizar preço",
          description: data.error ?? "Tente novamente.",
          variant: "destructive",
        });
        return;
      }
      onUpdated(data.product as MznProduct);
      toast({
        title: "Preço atualizado!",
        description: `${product.name}: ${formatPrice(parsed)}`,
      });
    } catch {
      toast({
        title: "Erro de conexão",
        description: "Não foi possível salvar o preço.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  }

  async function toggleActive(active: boolean) {
    try {
      const res = await fetch(`/api/admin/products/${product.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ active }),
      });
      const data = await res.json();
      if (!res.ok) return;
      onUpdated(data.product as MznProduct);
      toast({
        title: active ? "Produto visível" : "Produto oculto",
        description: `${product.name} ${active ? "está de volta à loja." : "foi ocultado da loja."}`,
      });
    } catch {
      /* silencioso */
    }
  }

  return (
    <TableRow className={product.active ? "" : "bg-muted/50 opacity-75"}>
      <TableCell>
        <div className="flex items-center gap-3">
          <div className="relative h-12 w-12 shrink-0 overflow-hidden rounded-lg border border-[#eadfca] bg-cream">
            {product.imageUrl ? (
              <Image
                src={product.imageUrl}
                alt={`Imagem do perfume ${product.name}`}
                fill
                sizes="48px"
                className="object-cover"
                unoptimized
              />
            ) : (
              <span className="flex h-full w-full items-center justify-center text-gold/50">
                <ImageOff className="h-5 w-5" />
              </span>
            )}
          </div>
          <div className="min-w-0">
            <p className="truncate font-medium text-gold-deep">{product.name}</p>
            <p className="truncate text-xs text-muted-foreground">
              Insp.: {product.inspiration}
            </p>
          </div>
        </div>
      </TableCell>
      <TableCell>
        <Badge variant="secondary" className="whitespace-nowrap">
          {GENDER_LABEL[product.gender] ?? product.gender}
        </Badge>
      </TableCell>
      <TableCell>
        <div className="flex items-center gap-1.5">
          <div className="relative">
            <span className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">
              R$
            </span>
            <Input
              inputMode="decimal"
              aria-label={`Preço de ${product.name}`}
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && changed) savePrice();
              }}
              className="h-9 w-24 pl-8 text-right font-semibold tabular-nums"
            />
          </div>
          <Button
            size="icon"
            variant={changed ? "default" : "ghost"}
            className="h-9 w-9 shrink-0"
            onClick={savePrice}
            disabled={!changed || saving}
            aria-label={`Salvar preço de ${product.name}`}
            title={changed ? "Salvar novo preço" : "Alterar o preço para salvar"}
          >
            {saving ? <Save className="h-4 w-4 animate-pulse" /> : changed ? <Check className="h-4 w-4" /> : <Save className="h-4 w-4" />}
          </Button>
        </div>
      </TableCell>
      <TableCell className="whitespace-nowrap text-sm text-muted-foreground">
        {product.volume}
      </TableCell>
      <TableCell>
        <Switch
          checked={product.active}
          onCheckedChange={toggleActive}
          aria-label={`Alternar visibilidade de ${product.name}`}
        />
      </TableCell>
      <TableCell>
        <div className="flex items-center gap-1">
          <Button
            size="icon"
            variant="ghost"
            className="h-9 w-9"
            onClick={() => onEdit(product)}
            aria-label={`Editar ${product.name}`}
            title="Editar produto"
          >
            <Pencil className="h-4 w-4" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="h-9 w-9 text-destructive hover:text-destructive"
            onClick={() => onDelete(product)}
            aria-label={`Excluir ${product.name}`}
            title="Excluir produto"
          >
            <Tag className="h-4 w-4 rotate-45" />
          </Button>
        </div>
      </TableCell>
    </TableRow>
  );
}

/* ------------------------- CONFIGURAÇÕES ------------------------- */

function SettingsTab({ settings }: { settings: MznSettings | null }) {
  const { toast } = useToast();
  const [whatsapp, setWhatsapp] = useState("");
  const [instagram, setInstagram] = useState("");
  const [saving, setSaving] = useState(false);

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [savingPassword, setSavingPassword] = useState(false);

  useEffect(() => {
    if (settings) {
      setWhatsapp(settings.whatsapp);
      setInstagram(settings.instagram);
    }
  }, [settings]);

  async function saveSettings(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ whatsapp, instagram }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast({ title: "Erro ao salvar", description: data.error, variant: "destructive" });
        return;
      }
      toast({ title: "Configurações salvas!", description: "A loja já exibe os novos contatos." });
    } catch {
      toast({ title: "Erro de conexão", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  async function changePassword(e: React.FormEvent) {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      toast({
        title: "As senhas não coincidem",
        description: "Confirme a nova senha corretamente.",
        variant: "destructive",
      });
      return;
    }
    setSavingPassword(true);
    try {
      const res = await fetch("/api/admin/password", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast({ title: "Erro ao alterar senha", description: data.error, variant: "destructive" });
        return;
      }
      toast({ title: "Senha alterada!", description: "Use a nova senha no próximo login." });
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    } catch {
      toast({ title: "Erro de conexão", variant: "destructive" });
    } finally {
      setSavingPassword(false);
    }
  }

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <form
        onSubmit={saveSettings}
        className="space-y-4 rounded-2xl border border-[#eadfca] bg-white p-6"
      >
        <h3 className="font-display text-xl font-semibold text-gold-deep">Contatos da loja</h3>
        <p className="text-sm text-muted-foreground">
          Estes contatos aparecem nos botões de WhatsApp e no rodapé do site.
        </p>
        <div className="grid gap-2">
          <Label htmlFor="set-wa">WhatsApp (com DDI e DDD, só números)</Label>
          <Input
            id="set-wa"
            value={whatsapp}
            onChange={(e) => setWhatsapp(e.target.value.replace(/\D/g, ""))}
            placeholder="5511999999999"
          />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="set-ig">Instagram</Label>
          <Input
            id="set-ig"
            value={instagram}
            onChange={(e) => setInstagram(e.target.value)}
            placeholder="@mzninspiracoes"
          />
        </div>
        <Button type="submit" disabled={saving} className="rounded-full">
          {saving ? "Salvando..." : "Salvar contatos"}
        </Button>
      </form>

      <form
        onSubmit={changePassword}
        className="space-y-4 rounded-2xl border border-[#eadfca] bg-white p-6"
      >
        <h3 className="flex items-center gap-2 font-display text-xl font-semibold text-gold-deep">
          <KeyRound className="h-5 w-5 text-gold" /> Alterar senha
        </h3>
        <div className="grid gap-2">
          <Label htmlFor="pw-current">Senha atual</Label>
          <Input
            id="pw-current"
            type="password"
            value={currentPassword}
            onChange={(e) => setCurrentPassword(e.target.value)}
            autoComplete="current-password"
            required
          />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="pw-new">Nova senha (mín. 6 caracteres)</Label>
          <Input
            id="pw-new"
            type="password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            autoComplete="new-password"
            minLength={6}
            required
          />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="pw-confirm">Confirmar nova senha</Label>
          <Input
            id="pw-confirm"
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            autoComplete="new-password"
            minLength={6}
            required
          />
        </div>
        <Button type="submit" disabled={savingPassword} className="rounded-full">
          {savingPassword ? "Alterando..." : "Alterar senha"}
        </Button>
      </form>
    </div>
  );
}

/* --------------------------- PAINEL PRINCIPAL --------------------------- */

export function AdminPanel({
  session,
  sessionLoading,
  settings,
  onSessionRefresh,
  onExitStore,
}: {
  session: AdminSessionInfo | null;
  sessionLoading: boolean;
  settings: MznSettings | null;
  onSessionRefresh: () => void;
  onExitStore: () => void;
}) {
  const { toast } = useToast();
  const [products, setProducts] = useState<MznProduct[] | null>(null);
  const [search, setSearch] = useState("");
  const [genderFilter, setGenderFilter] = useState<string>("ALL");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<MznProduct | null>(null);
  const [deleting, setDeleting] = useState<MznProduct | null>(null);

  const loadProducts = useCallback(async () => {
    try {
      const res = await fetch("/api/admin/products");
      if (res.status === 401) {
        onSessionRefresh();
        setProducts([]);
        return;
      }
      const data = await res.json();
      setProducts(data.products ?? []);
    } catch {
      setProducts([]);
    }
  }, [onSessionRefresh]);

  useEffect(() => {
    if (session?.authenticated) loadProducts();
  }, [session?.authenticated, loadProducts]);

  const filtered = useMemo(() => {
    if (!products) return null;
    const q = search.trim().toLowerCase();
    return products.filter((p) => {
      const matchQ =
        !q ||
        p.name.toLowerCase().includes(q) ||
        p.inspiration.toLowerCase().includes(q);
      const matchG = genderFilter === "ALL" || p.gender === genderFilter;
      return matchQ && matchG;
    });
  }, [products, search, genderFilter]);

  async function handleLogout() {
    await fetch("/api/auth/logout", { method: "POST" });
    onSessionRefresh();
    onExitStore();
  }

  async function handleDelete() {
    if (!deleting) return;
    try {
      const res = await fetch(`/api/admin/products/${deleting.id}`, {
        method: "DELETE",
      });
      const data = await res.json();
      if (!res.ok) {
        toast({ title: "Erro ao excluir", description: data.error, variant: "destructive" });
        return;
      }
      setProducts((prev) => (prev ? prev.filter((p) => p.id !== deleting.id) : prev));
      toast({
        title: "Produto excluído",
        description: `${deleting.name} foi removido do catálogo.`,
      });
    } catch {
      toast({ title: "Erro de conexão", variant: "destructive" });
    } finally {
      setDeleting(null);
    }
  }

  if (sessionLoading || (!session && settings === null)) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-cream">
        <div className="w-full max-w-md space-y-4 px-4">
          <Skeleton className="mx-auto h-16 w-16 rounded-full" />
          <Skeleton className="mx-auto h-8 w-64" />
          <Skeleton className="h-40 w-full rounded-2xl" />
        </div>
      </div>
    );
  }

  if (!session?.authenticated) {
    return (
      <>
        <LoginForm onSuccess={onSessionRefresh} onBackToStore={onExitStore} />
      </>
    );
  }

  return (
    <div className="flex min-h-screen flex-col bg-cream">
      {/* Barra superior do painel */}
      <header className="sticky top-0 z-40 border-b border-[#eadfca] bg-white/90 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4 sm:px-6">
          <div className="flex items-center gap-2.5">
            <Image
              src="/logo-mzn.svg"
              alt="Logotipo MZN Inspirações"
              width={40}
              height={40}
              className="h-9 w-9"
            />
            <div>
              <p className="font-display text-lg font-semibold leading-tight text-gold-deep">
                Painel MZN Inspirações
              </p>
              <p className="text-xs text-muted-foreground">
                Logado como <span className="font-medium text-gold">{session.username}</span>
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={onExitStore} className="rounded-full">
              <Store className="mr-1.5 h-4 w-4" /> Ver loja
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleLogout}
              className="rounded-full text-destructive hover:bg-destructive/10 hover:text-destructive"
            >
              <LogOut className="mr-1.5 h-4 w-4" /> Sair
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-8 sm:px-6">
        <Tabs defaultValue="produtos">
          <TabsList className="mb-6 rounded-full bg-secondary p-1">
            <TabsTrigger value="produtos" className="rounded-full px-6">
              Produtos
            </TabsTrigger>
            <TabsTrigger value="config" className="rounded-full px-6">
              Configurações
            </TabsTrigger>
          </TabsList>

          <TabsContent value="produtos" className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Buscar por nome ou inspiração..."
                    className="w-64 rounded-full pl-9"
                    aria-label="Buscar produtos"
                  />
                </div>
                <Select value={genderFilter} onValueChange={setGenderFilter}>
                  <SelectTrigger className="w-40 rounded-full" aria-label="Filtrar por gênero">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ALL">Todos os gêneros</SelectItem>
                    <SelectItem value="FEMININO">Feminino</SelectItem>
                    <SelectItem value="MASCULINO">Masculino</SelectItem>
                    <SelectItem value="UNISSEX">Unissex</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button
                onClick={() => {
                  setEditing(null);
                  setDialogOpen(true);
                }}
                className="rounded-full shadow-[0_8px_24px_-10px_rgba(168,132,44,0.7)]"
              >
                <Plus className="mr-1.5 h-4 w-4" /> Novo produto
              </Button>
            </div>

            <div className="overflow-hidden rounded-2xl border border-[#eadfca] bg-white shadow-[0_10px_36px_-24px_rgba(124,98,26,0.4)]">
              <div className="max-h-[65vh] overflow-auto gold-scrollbar">
                <Table>
                  <TableHeader className="sticky top-0 z-10 bg-cream/95 backdrop-blur">
                    <TableRow className="hover:bg-transparent">
                      <TableHead>Produto</TableHead>
                      <TableHead>Gênero</TableHead>
                      <TableHead>Preço (R$)</TableHead>
                      <TableHead>Volume</TableHead>
                      <TableHead>Na loja</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filtered === null ? (
                      Array.from({ length: 5 }).map((_, i) => (
                        <TableRow key={i}>
                          <TableCell colSpan={6}>
                            <Skeleton className="h-12 w-full" />
                          </TableCell>
                        </TableRow>
                      ))
                    ) : filtered.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="py-12 text-center text-muted-foreground">
                          Nenhum produto encontrado.
                        </TableCell>
                      </TableRow>
                    ) : (
                      filtered.map((p) => (
                        <ProductRow
                          key={p.id}
                          product={p}
                          onUpdated={(np) =>
                            setProducts((prev) =>
                              prev ? prev.map((old) => (old.id === np.id ? np : old)) : prev
                            )
                          }
                          onEdit={(prod) => {
                            setEditing(prod);
                            setDialogOpen(true);
                          }}
                          onDelete={setDeleting}
                        />
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              Dica: altere o preço e pressione Enter ou clique no botão de salvar para atualizar
              imediatamente na loja.
            </p>
          </TabsContent>

          <TabsContent value="config">
            <SettingsTab settings={settings} />
          </TabsContent>
        </Tabs>
      </main>

      <ProductDialog
        open={dialogOpen}
        product={editing}
        onClose={() => setDialogOpen(false)}
        onSaved={(p, isNew) => {
          setProducts((prev) => {
            if (!prev) return [p];
            if (isNew) return [...prev, p];
            return prev.map((old) => (old.id === p.id ? p : old));
          });
        }}
      />

      <AlertDialog open={!!deleting} onOpenChange={(v) => !v && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir produto?</AlertDialogTitle>
            <AlertDialogDescription>
              {deleting?.name} será removido permanentemente do catálogo. Esta
              ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-white hover:bg-destructive/90"
            >
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

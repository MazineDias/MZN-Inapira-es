"use client";

import { useEffect, useMemo, useState } from "react";
import Image from "next/image";
import { motion } from "framer-motion";
import {
  Clock,
  Droplets,
  Instagram,
  Lock,
  Menu,
  MessageCircle,
  Package,
  Sparkles,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  formatPrice,
  GENDER_LABEL,
  whatsappLink,
  type MznProduct,
  type MznSettings,
} from "@/components/mzn/types";

type Filter = "TODOS" | "FEMININO" | "MASCULINO" | "UNISSEX";

const FILTERS: { value: Filter; label: string }[] = [
  { value: "TODOS", label: "Todos" },
  { value: "FEMININO", label: "Feminino" },
  { value: "MASCULINO", label: "Masculino" },
  { value: "UNISSEX", label: "Unissex" },
];

function Logo({ className = "h-11 w-11" }: { className?: string }) {
  return (
    <Image
      src="/logo-mzn.svg"
      alt="Logotipo MZN Inspirações"
      width={88}
      height={88}
      className={className}
      priority
    />
  );
}

function ProductCard({ product, index }: { product: MznProduct; index: number }) {
  return (
    <motion.article
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.45, delay: (index % 4) * 0.06 }}
      className="card-lift group overflow-hidden rounded-2xl border border-[#eadfca] bg-card shadow-[0_8px_28px_-18px_rgba(124,98,26,0.35)]"
    >
      <div className="relative aspect-square overflow-hidden bg-cream">
        <Image
          src={product.imageUrl || "/images/perfumes/cristal-ouro.png"}
          alt={`Perfume artesanal ${product.name}, inspirado em ${product.inspiration}`}
          fill
          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
          className="object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <span className="absolute left-3 top-3 rounded-full bg-ivory/90 px-3 py-1 text-[11px] font-medium uppercase tracking-[0.14em] text-gold-deep shadow-sm backdrop-blur">
          {GENDER_LABEL[product.gender] ?? product.gender}
        </span>
      </div>
      <div className="flex flex-col gap-1.5 p-5">
        <h3 className="font-display text-2xl font-semibold leading-tight text-gold-deep">
          {product.name}
        </h3>
        <p className="text-xs uppercase tracking-[0.12em] text-muted-foreground">
          Inspirado em {product.inspiration}
        </p>
        <p className="mt-1 line-clamp-2 min-h-10 text-sm text-ink/70">{product.notes}</p>
        <div className="mt-3 flex items-center justify-between border-t border-[#f0e7d2] pt-3">
          <span className="rounded-full bg-secondary px-2.5 py-0.5 text-xs font-medium text-secondary-foreground">
            {product.volume}
          </span>
          <span className="font-display text-2xl font-bold text-gold">
            {formatPrice(product.price)}
          </span>
        </div>
      </div>
    </motion.article>
  );
}

function ProductCardSkeleton() {
  return (
    <div className="overflow-hidden rounded-2xl border border-[#eadfca] bg-card">
      <Skeleton className="aspect-square w-full rounded-none" />
      <div className="flex flex-col gap-2 p-5">
        <Skeleton className="h-6 w-2/3" />
        <Skeleton className="h-3 w-1/2" />
        <Skeleton className="h-3 w-full" />
        <Skeleton className="mt-2 h-7 w-1/3" />
      </div>
    </div>
  );
}

export function Storefront({
  settings,
  onOpenAdmin,
}: {
  settings: MznSettings;
  onOpenAdmin: () => void;
}) {
  const [products, setProducts] = useState<MznProduct[] | null>(null);
  const [filter, setFilter] = useState<Filter>("TODOS");
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    let alive = true;
    fetch("/api/products")
      .then((r) => r.json())
      .then((data: { products: MznProduct[] }) => {
        if (alive) setProducts(data.products ?? []);
      })
      .catch(() => {
        if (alive) setProducts([]);
      });
    return () => {
      alive = false;
    };
  }, []);

  const filtered = useMemo(() => {
    if (!products) return null;
    return filter === "TODOS"
      ? products
      : products.filter((p) => p.gender === filter);
  }, [products, filter]);

  const waHref = whatsappLink(
    settings.whatsapp,
    "Olá! Vim pelo site da MZN Inspirações e gostaria de conhecer os perfumes."
  );

  const navLinks = [
    { href: "#perfumes", label: "Perfumes" },
    { href: "#sobre", label: "Sobre" },
    { href: "#contato", label: "Contato" },
  ];

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* CABEÇALHO */}
      <header className="sticky top-0 z-40 border-b border-[#eadfca]/70 bg-white/85 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
          <a href="#" className="flex items-center gap-2.5" aria-label="MZN Inspirações — início">
            <Logo className="h-10 w-10" />
            <span className="font-display text-2xl font-semibold tracking-wide text-gold-deep">
              MZN <span className="gold-gradient-text">Inspirações</span>
            </span>
          </a>
          <nav className="hidden items-center gap-8 md:flex" aria-label="Navegação principal">
            {navLinks.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className="text-sm font-medium tracking-wide text-ink/80 transition-colors hover:text-gold"
              >
                {l.label}
              </a>
            ))}
            <button
              onClick={onOpenAdmin}
              className="flex h-9 w-9 items-center justify-center rounded-full border border-[#eadfca] text-gold transition-colors hover:bg-secondary"
              aria-label="Área administrativa"
              title="Área administrativa"
            >
              <Lock className="h-4 w-4" />
            </button>
          </nav>
          <button
            className="flex h-10 w-10 items-center justify-center rounded-full text-gold-deep md:hidden"
            onClick={() => setMenuOpen((v) => !v)}
            aria-label={menuOpen ? "Fechar menu" : "Abrir menu"}
            aria-expanded={menuOpen}
          >
            {menuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
        {menuOpen && (
          <nav className="border-t border-[#eadfca]/70 bg-white px-6 py-4 md:hidden" aria-label="Menu móvel">
            {navLinks.map((l) => (
              <a
                key={l.href}
                href={l.href}
                onClick={() => setMenuOpen(false)}
                className="block py-2.5 text-sm font-medium text-ink/80"
              >
                {l.label}
              </a>
            ))}
            <button
              onClick={() => {
                setMenuOpen(false);
                onOpenAdmin();
              }}
              className="flex items-center gap-2 py-2.5 text-sm font-medium text-gold"
            >
              <Lock className="h-4 w-4" /> Área administrativa
            </button>
          </nav>
        )}
      </header>

      <main className="flex-1">
        {/* HERO */}
        <section className="relative overflow-hidden" aria-label="Apresentação">
          <div className="absolute inset-0">
            <Image
              src="/images/hero.png"
              alt="Coleção de perfumes artesanais em frascos brancos e dourados"
              fill
              priority
              sizes="100vw"
              className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-white via-white/80 to-white/10" />
            <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-white to-transparent" />
          </div>
          <div className="relative mx-auto flex min-h-[560px] max-w-6xl flex-col justify-center px-4 py-20 sm:px-6 md:min-h-[640px]">
            <motion.div
              initial={{ opacity: 0, y: 28 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
              className="max-w-xl"
            >
              <p className="mb-4 text-xs font-medium uppercase tracking-[0.3em] text-gold">
                Perfumaria artesanal
              </p>
              <h1 className="font-display text-5xl font-semibold leading-[1.05] text-gold-deep sm:text-6xl">
                O luxo das grandes{" "}
                <span className="gold-gradient-text">grifes</span>, no frasco
                que você merece
              </h1>
              <p className="mt-6 text-lg leading-relaxed text-ink/75">
                Perfumes artesanais inspirados nas marcas mais desejadas do
                mundo. Óleos concentrados de alta fixação, feitos à mão em
                pequenos lotes — elegância que cabe no seu bolso.
              </p>
              <div className="mt-8 flex flex-wrap gap-4">
                <Button
                  asChild
                  size="lg"
                  className="h-12 rounded-full px-8 text-base shadow-[0_10px_30px_-10px_rgba(168,132,44,0.6)]"
                >
                  <a href="#perfumes">Ver catálogo</a>
                </Button>
                <Button
                  asChild
                  size="lg"
                  variant="outline"
                  className="h-12 rounded-full border-gold/40 px-8 text-base text-gold-deep hover:bg-secondary hover:text-gold-deep"
                >
                  <a href="#sobre">Nossa história</a>
                </Button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* FAIXA DE DIFERENCIAIS */}
        <section aria-label="Diferenciais" className="border-y border-[#eadfca]/70 bg-cream">
          <div className="mx-auto grid max-w-6xl grid-cols-1 gap-6 px-4 py-8 sm:grid-cols-3 sm:px-6">
            {[
              { icon: Droplets, title: "Óleos concentrados", sub: "Perfumaria de qualidade europeia" },
              { icon: Clock, title: "Fixação prolongada", sub: "Presença que dura o dia todo" },
              { icon: Sparkles, title: "Feito à mão", sub: "Pequenos lotes, cuidado em cada detalhe" },
            ].map((f) => (
              <div key={f.title} className="flex items-center gap-4">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-white text-gold shadow-sm ring-1 ring-[#eadfca]">
                  <f.icon className="h-5 w-5" />
                </span>
                <div>
                  <p className="font-medium text-gold-deep">{f.title}</p>
                  <p className="text-sm text-ink/60">{f.sub}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* CATÁLOGO */}
        <section id="perfumes" className="scroll-mt-20 py-16 sm:py-20" aria-label="Catálogo de perfumes">
          <div className="mx-auto max-w-6xl px-4 sm:px-6">
            <div className="mb-10 text-center">
              <p className="mb-2 text-xs font-medium uppercase tracking-[0.3em] text-gold">
                Nossa coleção
              </p>
              <h2 className="font-display text-4xl font-semibold text-gold-deep sm:text-5xl">
                Perfumes <span className="gold-gradient-text">MZN</span>
              </h2>
              <div className="gold-hairline mx-auto mt-4 w-40" aria-hidden="true" />
              <p className="mx-auto mt-4 max-w-xl text-ink/70">
                Fragrâncias inspiradas nas grandes marcas, com 50ml de pura
                sofisticação. Preços atualizados diretamente pela loja.
              </p>
            </div>

            <div className="mb-10 flex flex-wrap justify-center gap-2.5" role="tablist" aria-label="Filtrar por gênero">
              {FILTERS.map((f) => (
                <button
                  key={f.value}
                  role="tab"
                  aria-selected={filter === f.value}
                  onClick={() => setFilter(f.value)}
                  className={`rounded-full px-5 py-2 text-sm font-medium transition-all ${
                    filter === f.value
                      ? "bg-gold text-ivory shadow-[0_8px_20px_-8px_rgba(168,132,44,0.7)]"
                      : "border border-[#eadfca] bg-white text-ink/70 hover:border-gold/50 hover:text-gold-deep"
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            {!filtered ? (
              <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
                {Array.from({ length: 4 }).map((_, i) => (
                  <ProductCardSkeleton key={i} />
                ))}
              </div>
            ) : filtered.length === 0 ? (
              <p className="py-12 text-center text-ink/60">
                Nenhum perfume nesta categoria por enquanto.
              </p>
            ) : (
              <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
                {filtered.map((p, i) => (
                  <ProductCard key={p.id} product={p} index={i} />
                ))}
              </div>
            )}
          </div>
        </section>

        {/* SOBRE */}
        <section id="sobre" className="scroll-mt-20 border-y border-[#eadfca]/70 bg-cream py-16 sm:py-20" aria-label="Sobre a loja">
          <div className="mx-auto grid max-w-6xl items-center gap-12 px-4 sm:px-6 lg:grid-cols-2">
            <motion.div
              initial={{ opacity: 0, x: -24 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <p className="mb-2 text-xs font-medium uppercase tracking-[0.3em] text-gold">
                Nossa história
              </p>
              <h2 className="font-display text-4xl font-semibold text-gold-deep sm:text-5xl">
                Sobre a <span className="gold-gradient-text">MZN Inspirações</span>
              </h2>
              <div className="mt-6 space-y-4 leading-relaxed text-ink/75">
                <p>
                  A MZN Inspirações nasceu de uma paixão: tornar as grandes
                  fragrâncias do mundo acessíveis a quem ama perfumar-se bem,
                  sem abrir mão da qualidade. Cada perfume é formulado à mão,
                  em pequenos lotes, com óleos concentrados selecionados com
                  rigor.
                </p>
                <p>
                  Nossas inspirações nas grandes grifes são fiéis ao espírito
                  de cada fragrância — do doce marcante ao cítrico fresco — e
                  passam por testes de fixação antes de chegar até você. O
                  resultado é um luxo real, num frasco elegante de 50ml que
                  cabe no dia a dia.
                </p>
              </div>
              <ul className="mt-8 grid gap-4 sm:grid-cols-2">
                {[
                  { icon: Droplets, text: "Óleos concentrados importados" },
                  { icon: Clock, text: "Fixação de 8 horas ou mais" },
                  { icon: Package, text: "Frascos elegantes de 50ml" },
                  { icon: Sparkles, text: "Produção artesanal em pequenos lotes" },
                ].map((item) => (
                  <li key={item.text} className="flex items-center gap-3">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-white text-gold shadow-sm ring-1 ring-[#eadfca]">
                      <item.icon className="h-4 w-4" />
                    </span>
                    <span className="text-sm text-ink/80">{item.text}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 0.96 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="relative mx-auto w-full max-w-md"
            >
              <div className="absolute -inset-3 rounded-[2rem] border border-gold/30" aria-hidden="true" />
              <div className="relative aspect-square overflow-hidden rounded-[1.75rem] shadow-[0_24px_60px_-24px_rgba(124,98,26,0.45)]">
                <Image
                  src="/images/perfumes/cristal-ouro.png"
                  alt="Frasco de perfume artesanal cristal dourado da MZN Inspirações"
                  fill
                  sizes="(max-width: 1024px) 90vw, 448px"
                  className="object-cover"
                />
              </div>
            </motion.div>
          </div>
        </section>

        {/* CTA CONTATO */}
        <section id="contato" className="scroll-mt-20 py-16 sm:py-20" aria-label="Contato">
          <div className="mx-auto max-w-6xl px-4 sm:px-6">
            <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#8c6d1f] via-[#a8842c] to-[#d4af37] px-6 py-14 text-center shadow-[0_24px_60px_-24px_rgba(140,109,31,0.7)] sm:px-12">
              <div className="absolute -left-10 -top-10 h-40 w-40 rounded-full bg-white/10 blur-2xl" aria-hidden="true" />
              <div className="absolute -bottom-12 -right-8 h-48 w-48 rounded-full bg-white/10 blur-2xl" aria-hidden="true" />
              <h2 className="relative font-display text-3xl font-semibold text-white sm:text-4xl">
                Encontre a sua fragrância
              </h2>
              <p className="relative mx-auto mt-3 max-w-lg text-white/85">
                Fale conosco no WhatsApp e descubra qual inspiração combina
                com você. Atendimento personalizado e envio para todo o Brasil.
              </p>
              <div className="relative mt-8 flex flex-wrap items-center justify-center gap-4">
                <Button
                  asChild
                  size="lg"
                  className="h-12 rounded-full bg-white px-8 text-base font-semibold text-gold-deep hover:bg-cream"
                >
                  <a href={waHref} target="_blank" rel="noopener noreferrer">
                    <MessageCircle className="mr-2 h-5 w-5" />
                    Falar no WhatsApp
                  </a>
                </Button>
                {settings.instagram && (
                  <Button
                    asChild
                    size="lg"
                    variant="outline"
                    className="h-12 rounded-full border-white/50 bg-transparent px-8 text-base text-white hover:bg-white/10 hover:text-white"
                  >
                    <a
                      href={`https://instagram.com/${settings.instagram.replace(/^@/, "")}`}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Instagram className="mr-2 h-5 w-5" />
                      {settings.instagram}
                    </a>
                  </Button>
                )}
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* RODAPÉ */}
      <footer className="mt-auto border-t border-[#eadfca] bg-ivory pb-[env(safe-area-inset-bottom)]">
        <div className="mx-auto grid max-w-6xl gap-10 px-4 py-12 sm:grid-cols-3 sm:px-6">
          <div>
            <div className="flex items-center gap-2.5">
              <Logo className="h-9 w-9" />
              <span className="font-display text-xl font-semibold text-gold-deep">
                MZN Inspirações
              </span>
            </div>
            <p className="mt-3 max-w-xs text-sm leading-relaxed text-ink/60">
              Perfumes artesanais inspirados nas grandes marcas e grifes.
              Luxo acessível, feito à mão.
            </p>
          </div>
          <nav aria-label="Links do rodapé">
            <p className="mb-3 text-xs font-semibold uppercase tracking-[0.2em] text-gold">
              Navegue
            </p>
            <ul className="space-y-2 text-sm text-ink/70">
              {navLinks.map((l) => (
                <li key={l.href}>
                  <a href={l.href} className="transition-colors hover:text-gold">
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
          <div>
            <p className="mb-3 text-xs font-semibold uppercase tracking-[0.2em] text-gold">
              Contato
            </p>
            <ul className="space-y-2 text-sm text-ink/70">
              <li>
                <a
                  href={waHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 transition-colors hover:text-gold"
                >
                  <MessageCircle className="h-4 w-4 text-gold" /> WhatsApp
                </a>
              </li>
              {settings.instagram && (
                <li>
                  <a
                    href={`https://instagram.com/${settings.instagram.replace(/^@/, "")}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 transition-colors hover:text-gold"
                  >
                    <Instagram className="h-4 w-4 text-gold" /> {settings.instagram}
                  </a>
                </li>
              )}
            </ul>
          </div>
        </div>
        <div className="border-t border-[#eadfca]">
          <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-4 py-5 text-xs text-ink/50 sm:flex-row sm:px-6">
            <p>© {new Date().getFullYear()} MZN Inspirações · Perfumaria artesanal</p>
            <button
              onClick={onOpenAdmin}
              className="inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-ink/50 transition-colors hover:text-gold"
              aria-label="Abrir painel administrativo"
            >
              <Lock className="h-3.5 w-3.5" /> Área Administrativa
            </button>
          </div>
        </div>
      </footer>

      {/* BOTÃO FLUTUANTE WHATSAPP */}
      <a
        href={waHref}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-5 right-5 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-gold text-ivory shadow-[0_12px_30px_-8px_rgba(168,132,44,0.8)] transition-transform hover:scale-110"
        aria-label="Conversar no WhatsApp"
      >
        <MessageCircle className="h-6 w-6" />
      </a>
    </div>
  );
}
